﻿#include "pch.h"
#include "tipsware.h"

NOT_USE_MESSAGE;

int main()
{


    ShowDisplay(); // 정보를 윈도우에 출력한다.
    return 0;
}
