﻿// pch.cpp: 미리 컴파일된 헤더에 해당하는 소스 파일

#include "pch.h"

/*
// 응용 프로그램이 사용하는 내부 윈도우 클래스 이름입니다. (수정 가능)
const char *gp_app_name = "ExamGameMacro";
// 응용 프로그램이 사용하는 제목입니다. (수정 가능)
const char *gp_window_title = "게임용 매크로 예제(Step 1, https://blog.naver.com/tipsware)";
// 응용 프로그램이 사용할 메뉴의 ID입니다. (0이면 메뉴를 사용하지 않는다는 뜻입니다.)
*/